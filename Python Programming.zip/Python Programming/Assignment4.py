
user_input = input("Enter a string ")
my_list=list(range(1,101))
user_input_lower = user_input.lower()
if user_input_lower==user_input :
	print(my_list[7:99])
else :
	print( "python mane shaper child ",len(user_input))