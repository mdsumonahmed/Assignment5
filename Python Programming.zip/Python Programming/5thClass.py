num = int(input("enter a number"))
if num%3==0 and num%5==0:
	if num>0:
		print("number is found")
else:
	print("number is not found")		