class Calculator:

	def add(self,a,b):
		return a+b

	def sub(self,a,b):
		return a-b

	def multi(self,a,b):
		return a*b	

if__name==__"main"__:
	obj = Calculator()
	print(obj.add(5,5))
	print(obj.sub(5,5))
	print(obj.multi(5,5))		