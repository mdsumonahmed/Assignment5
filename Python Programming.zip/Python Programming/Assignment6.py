
input_num = int(input("Enter your valu "))

def check_positive(input_num):
	if input_num>0:
		print(input_num,"is positive number")
	else:
		print(input_num,"is negative number")

def check_prime(input_num):
	flag = 0
	for i in range(2,input_num-1):
		if (input_num % i) == 0:
			flag = 1
			break
		else:
			flag = 0
	return flag

check_positive(input_num)		
if input_num>0:			
	flag = check_prime(input_num)

	if flag==1:
		print(input_num,"is positive and prime")
	else:
		print(input_num,"is positive and not prime")
else:
	flag = check_prime(input_num)

	if flag==1:
		print(input_num,"is negative and prime")
	else:
		print(input_num,"is negative and not prime")		