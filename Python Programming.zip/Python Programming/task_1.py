SEU_ID="2020000010012"
ID_LEN=len(SEU_ID)
BIRTH_YEAR=1999

firstFiveDigit = int( SEU_ID[0:5] )
lastThreeDigit = int( SEU_ID[ID_LEN-3: ID_LEN] )
lastDigit = int( SEU_ID[ID_LEN-1:ID_LEN] )

sumOfTwoPortion = firstFiveDigit + lastThreeDigit
multipliedResult = (BIRTH_YEAR - lastThreeDigit) * lastDigit 

print(f"{sumOfTwoPortion = }", type(sumOfTwoPortion))

print(f"{multipliedResult = }", type(multipliedResult))
