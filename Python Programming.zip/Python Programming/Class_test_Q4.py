
import random as rm
def minimumNum(rdList):
	return min(rdList)

def maximumNum(rdList):
	return max(rdList)

def sumNum(rdList):
	return sum(rdList)

rdList = []
for i in range(0,20):
	num = rm.randint(1,20)
	if(num%3==0):
		rdList.append(num)

print("min num is ",minimumNum(rdList))
print("max num is ",maximumNum(rdList))
print("sum of num is ",sumNum(rdList))
