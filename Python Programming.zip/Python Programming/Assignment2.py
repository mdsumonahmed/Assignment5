 
student_id = 2020000010017
ph_last_digit = 4
birth_year_digit = 997

result = student_id/ph_last_digit+birth_year_digit
print("%.3f"%result)
