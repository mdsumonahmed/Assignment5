
d = ["Md.Sumon Hosen",2020000010017,7,"Lionel Messi","CSE",1.4]
d.append("Mortaza")
print(d)
d.pop(1)
print(d)
d.extend(["boshen boshen", "poribeshta shundor na?", "don't love me", 2.0, 1990, "AK 47"])
print(d,"\nlength is ",len(d));