
list1 = [10, 21, 4, 45, 66, 93]

for num in list1:
	
	# checking condition
	if num % 2 != 0:
		print(num, end = " ")
