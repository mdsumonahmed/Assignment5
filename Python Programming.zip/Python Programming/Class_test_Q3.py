
def display(nume):
	length = len(nume)
	n=2
	for i in (0,length):
		print(nume[n])
		n=n+2

nume = input(" Enter a string :") 
display(nume)