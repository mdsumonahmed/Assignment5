#ID=2020000010017
ID_f5=20200
ID_f3=17
multiply = ID_f5*ID_f3
print(multiply,type(multiply))

birth_year = 1997
divide = birth_year/ID_f3
subtract = divide-7
print(divide,type(divide)) 