"""file = open("mytext.txt","w")
file.write("hello bangladesh")
file.close()

files = open("mytext.txt","r")
print(files.read())
files.close()
"""

with open("mytext.txt","w") as file:
	file.write("My name is Sumon Ahmed ")

with open("mytext.txt","r") as file:
	print(file.read())	

with open("mytext.txt","a") as file:
	file.write("My name is Sumon Ahmed")

with open("mytext.txt","r") as file:
	print(file.read())			