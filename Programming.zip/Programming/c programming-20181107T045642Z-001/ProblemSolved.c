#include<stdio.h>
int main()
{

printf("kjlkd");
return 0;
}
