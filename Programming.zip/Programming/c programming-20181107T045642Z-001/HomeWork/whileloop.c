#include<stdio.h>
#include<stdlib.h>
int main()
{
    int i = 1, k = 1, n = 150;
    long  sum1 = 0, sum2 = 0, sum3 = 0;
    while( i <= n) {

        sum1 = sum1 + k;

        if( i == 25) {
            sum2 = k;
        }
        if(i == 30) {
            sum3 = sum1;
        }
        k = k + 3;
        i++;
    }
    sum2 = sum1 - sum2;

    printf("%ld\n%ld\n%ld\n", sum1, sum2, sum3);


    return 0;
}
