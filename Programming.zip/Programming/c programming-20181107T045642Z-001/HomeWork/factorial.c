#include<stdio.h>
int main(){
    int n,fact,i;
    fact = 1;
    i =1;
    scanf("%d",&n);
    while(i<=n){
        fact = fact*i;
        i++;
    }

    printf("fact is = %d\n",fact);
    return 0;
}
