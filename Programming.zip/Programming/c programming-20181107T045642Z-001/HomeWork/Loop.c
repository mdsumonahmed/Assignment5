#include<stdio.h>
int main(){
    int j,n=5;
    for(j=n; j>=1; j=j/4)
    {
        printf("\n a");
    }
    return 0;
}
