#include<stdio.h>
int main(){
    int t,i,a,b;
    long int result;
    scanf("%d",&t);
    int n[t];
    for(int i = 0; i<t; i++){
        scanf("%d",&n[i]);
    }

    for(i = 0; i<t; i++){
        result = 0;
        a = n[i]-1;
        b = 1;
        while(a>b){
            result ++;
            a = a-1;
            b = b+1;
        }
        printf("%d\n",result);
    }

return 0;
}
