#include<stdio.h>
int main()
{
    int arr[6] = {5,2,9,12,7,4};
    int i,j,n,temp = 0;
    int step = 1;
    n = sizeof(arr)/sizeof(arr[0]);

    for(i=n; i>0; i--){

        printf("step %d\n",step);
        step++;

        j = 0;
        while(j<i){

            if(arr[j]>arr[j+1]){
                temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
            for(int k = 0; k<n; k++){
            printf("%d ",arr[k]);
            }
            printf("\n");
            j++;
        }

    }


    return 0;
}
