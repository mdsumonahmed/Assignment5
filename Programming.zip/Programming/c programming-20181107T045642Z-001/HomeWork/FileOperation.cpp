#include<bits/stdc++.h>
using namespace std;
int main(){
    clock_t t = clock();
    cout<<t;
return 0;
}
