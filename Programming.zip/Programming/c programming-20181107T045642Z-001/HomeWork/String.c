#include<stdio.h>
int main(){


    char c;
    char cs[100];
    char sen[100];

    scanf("%c",&c);
    scanf("%s\n",&cs);
    scanf("%[^\n]%*c", sen);

    printf("%c\n",c);
    printf("%s\n",cs);
    printf("%s",sen);


    return 0;
}
