#include<stdio.h>
#include<string.h>
void constructString(int n, int b) {
    int ch = 97;
    int c = 1;
    for (int i = 0; i < n; i++) {
        if (c > b) {
            c = 1;
            ch = 97;
        }
       // cout << (char) ch;
        printf("%c",ch);
        ch++;
        c++;
    }
    //cout << "\n";
    printf("\n");
}

int main() {
    int test;
    //cin >> test;
    scanf("%d",&test);
    for (int i = 0; i < test; i++) {
        int n, a, b;
        //cin >> n >> a >> b;
        scanf("%d %d %d",&n,&a,&b);
        constructString(n, b);
    }
    return 0;
}
