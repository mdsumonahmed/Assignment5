#include <stdio.h>
#include<stdlib.h>
int main() {
    int i, sum1 = 0, sum2 = 0;
    int n = 100;

    int array[100];

    for(i = 0; i < n; i++) {
        array[i] = 1;
    }

    for(i = 0; i < n; i++) {
        sum1 = sum1 + array[i];
    }

    for(i = 0; i < n; i++) {
        array[i] = 2;
    }

    for(i = 0; i < n; i++) {
        sum2 = sum2 + array[i];
    }

    printf("%d\n%d\n", sum1, sum2);
    return 0;
}
