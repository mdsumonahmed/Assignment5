#include <stdio.h>
#include <stdlib.h>

void main()
{
    int i,sum=0;
    for(i=0;i<=100;i++)
    {
        sum = sum+2;

        printf("%d ",sum);
    }

    return 0;
}
