#include<stdio.h>


void pass(int a[],int n){
    n++;
    printf("%d\n",n);
    for(int i=0 ; i<n; i++)
        printf("%d ",a[i]);
}
int main(){
    int n;
    scanf("%d",&n);
    int arr[n];

    for(int i = 0; i<n; i++){
        scanf("%d",&arr[i]);
    }
    pass(arr,n);

return 0;
}
