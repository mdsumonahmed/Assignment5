
#include<stdio.h>
int main()
{
    int rem[1];
    int arr[6] = {5,1,3,4,6,2};
    int size = sizeof(arr)/sizeof(0);
    printf("length is %d\n",size);
    for(int i = 0; i<size; i++){
        for(int j = i; j <size; j++){
            if(arr[i]>arr[j]){
                rem[0] = arr[j];
                arr[j] = arr[i];
                arr[i] = rem[0];
            }
            }

          for(int k = 0; k<size; k++)
            printf("%d\t",arr[k]);
            printf("\n");
        }


    return 0;
}
