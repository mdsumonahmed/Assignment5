#include<stdio.h>
#include<stdlib.h>
int rows;
int i,j;

void inverted_right_triangle(){
    printf("enter row number\n");
    scanf("%d",&rows);
    //inverted right triangle;
    for(i=rows;i>=1;i--){

        for(j=1;j<=i;j++){
            printf("* ");


        }
        printf("\n");
    }
}

void inverted_left_triangle(){
    int rows;
    int i,j;
    scanf("%d",&rows);
    for(i=1;i<=rows;i++){

        for(j=rows;j>=i;j--){
            printf(" *");
        }
        printf("\n");
        //printf(" ",i);
        for(int s = 1;s<=i;s++){
            printf("  ");
        }
   }
}

void left_triangle(){
    int rows;
    int i,j;
    scanf("%d",&rows);
    for(i=1;i<=rows;i++){

        for(int space=1;space<=rows-i;space++){
            printf("  ");
        }
        for(j=1;j<=i;j++){
            printf("* ");
        }

        printf("\n");
    }
}
void piramid(){
    int n,row,col;
    printf("enter row number : ");
    scanf("%d",&n);

    for(row=1;row<=n;row++){

        for(col=1;col<=n-row;col++)
        {
            printf(" ",col);
        }
        for(col=1;col<=row;col++)
        {
            printf("* ",col);
        }

        printf("\n",row);
    }
}

void inverted_piramid(){
    int n,row,col;
    printf("enter row number : ");
    scanf("%d",&n);
    for(int row=1; row<=n;row++){
        for(col=1;col<row;col++){
            printf(" ",col);
        }
        for(col=1;col<=n-row;col++){
            printf("* ");
        }

        printf("\n",row);
    }
    return 0;
}
int main(){

    //inverted_right_triangle();
    //inverted_left_triangle();
    //left_triangle();
    //piramid();
    inverted_piramid();
    return 0;
}
