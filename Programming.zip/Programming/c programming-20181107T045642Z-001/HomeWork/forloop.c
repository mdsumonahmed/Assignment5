#include<stdio.h>
#include<stdlib.h>
int main()
{
    int i, n = 2000;
    long  sum = 0;

    for(i = 2; i <= n; i = i + 2) {
        sum = sum + i;
    }

    printf("%ld\n", sum);

    return 0;
}
