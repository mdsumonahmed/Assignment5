#include<stdio.h>
int main(){
int a = 12;
int b = 25;
printf("%d\n",a^b);
return 0;
}
