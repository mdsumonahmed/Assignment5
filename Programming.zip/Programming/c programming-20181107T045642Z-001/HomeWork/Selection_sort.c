#include<stdio.h>
int main()
{
    int k=0,z;
    int temp[1];
    int arr[6] = {5,1,3,4,6,2};
    int size = sizeof(arr)/sizeof(0);
    printf("length is %d\n",size);
    for(int i = 0; i<size; i++){
        temp[0] = arr[i];
        for(int j = i; j <size; j++){
            if(arr[j] <= temp[0]){
                temp[0] = arr[j];
                k = j;
            }
        }

          temp[0] = arr[k];
          arr[k] = arr[i];
          arr[i] = temp[0];
          for(int z = 0; z<size; z++)
            printf("%d  ",arr[z]);
            printf("\n\n");
        }


    return 0;
}
