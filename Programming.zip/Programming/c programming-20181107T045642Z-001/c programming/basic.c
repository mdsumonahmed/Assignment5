#include<stdio.h>
int main()
{
    char a[]="bangladesh";
    printf("%s",a);
}
