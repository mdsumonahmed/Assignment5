#include<stdio.h>
int main()
{
    int m,n,i,GCD,LCM;
    printf("enter any two number=:\n");
    scanf("%d %d",&m,&n);

    for(i=2;i<=m && i<=n;i++)
    {
        if(n%i==0 && m%i==0)
        {
            GCD=i;

        }
    }
    LCM=(m*n)/GCD;
    printf("LCM=%d GCD=%d",LCM,GCD);


}
