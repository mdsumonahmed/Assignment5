#include<stdio.h>
void main()
{
int arr[10]={11,22,33,66,5,544,44,43,32,21,};
int i,j,k,temp;
for(i=0; i<10; i++)
{
for(j=0; j<10-1; j++)
{
if(arr[j]> arr[j+1])
{
temp = arr[j];
arr[j] = arr[j+1];
arr[j+1] = temp;
}
}
}
for(k = 0; k<10; k++)
{
printf("%d\n", arr[k]);
}
}
