#include<stdio.h>
int main()
{
    int A[10][10],sum=0,row,col,i,j;
    printf("enter number for row and col:");
    scanf("%d %d",&row,&col);

    for(i=0;i<row;i++){
        for(j=0;j<col;j++)
        {
            printf("A[%d][%d]=",i,j);
            scanf("%d",&A[i][j]);
        }
        printf("\n");
    }

    for(i=0;i<row;i++){
        for(j=0;j<col;j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");
    }

    printf("digonal elements ");
    for(i=0;i<row;i++){
        for(j=0;j<col;j++)
        {
            if(i==j)
            {
                printf("%d ",A[i][j]);
                sum=sum+A[i][j];
            }
        }
    }
    printf("\nsum of digonal elements=%d ",sum);
}
