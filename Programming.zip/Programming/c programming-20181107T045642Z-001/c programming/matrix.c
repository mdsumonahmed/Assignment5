#include<stdio.h>
void main()
{
    int A[4][4],B[4][4],C[4][4];
    int i,j;

    printf("Enter first matrix:\n");
    for(i=0;i<4;i++)
    {
        for(j=0;j<4;j++)
        {
            scanf("%d",&A[i][j]);
        }
    }

     for(i=0;i<4;i++)
    {
        for(j=0;j<4;j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");
    }
    //printf("\n");
    printf("Enter second matrix: \n");
    for(i=0;i<4;i++)
    {
        for(j=0;j<4;j++)
        {
            scanf("%d",&B[i][j]);
        }
    }
    for(i=0;i<4;i++)
    {
        for(j=0;j<4;j++)
        {
        printf("%d\n",B[i][j]);
        }
        printf("\n");
    }
    printf("sum of two matrix: \n");
    for(i=0;i<4;i++)
    {
        for(j=0;j<4;j++)
        {
            C[i][j]=A[i][j]+B[i][j];
            printf("%d\n",C[i][j]);
        }
        printf("\n");
    }

   return 0;
}
