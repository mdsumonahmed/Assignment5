#include<stdio.h>
int main()
{
    int first=0,second=1,n,i,next;
    while(1) {
        for(i=1;i<=n;i++) {
            next=first=second;
            first=second;
            second=first;
            printf("%d\n",next);
        }
    }

}
