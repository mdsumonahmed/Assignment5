#include<stdio.h>
int main()
{
    int num,rev,n,reminder;
    rev=0;
    printf("enter a number");
    scanf("%d",num);
    n=num;
    while(num>0)
    {
        reminder=num%10;
        rev=rev*10+reminder;
        num=num/10;
    }
    if(n==rev)
    printf("The number is a palindrome.%d\n",rev);
    else
        printf("The number is not palindrome.%d\n");


    return 0;
}
