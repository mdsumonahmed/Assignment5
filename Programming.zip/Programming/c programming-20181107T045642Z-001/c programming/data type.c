#include<stdio.h>
int main()
{
    printf("Storage size for int: %d\n",sizeof(int));
    printf("Storage size for float : %d \n", sizeof(float));
    printf("Storage size for long : %d \n", sizeof(long));

}
