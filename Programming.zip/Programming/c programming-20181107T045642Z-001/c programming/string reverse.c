#include<stdio.h>
int main()
{
    char str[]="sumon ahmed";
    strrev(str);
    printf("str = %s\n",str);

}
