#include<stdio.h>
void main()
{
int a,b,c;
a=1600;
b=3000;
c=a*b;
printf("%d",c);

}
