#include<stdio.h>
void main()
{
    int arr[4][4]={{10,20,30,40},{50,60,70,80},{90,100,110,120},{130,140,150,160}};
    int i,j;
    for(i=0;i<4;i++){
        for(j=0;j<4;j++){
            printf("a[%d][%d]=[%d]\n", i,j,arr[i][j]);
        }
    }
}
