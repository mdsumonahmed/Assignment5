#include<stdio.h>
int main()
{
    int a=0,b=1,c=1,d=0,i,n;
    printf("Enter see number");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        d=a+b+c;
        a=b;
        b=c;
        c=d;

        printf("%d ",c);
    }
    getchar();
}
