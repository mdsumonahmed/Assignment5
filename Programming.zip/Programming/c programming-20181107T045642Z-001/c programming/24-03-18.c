#include<stdio.h>
int a,b;
int add(int a,int b)
{
    return a+b;
}
int mal(int m,int n)
{
   int a=m;
    int b=n;
    return=a*b;
}
void main()
{
    printf("num=%d",add(200,500));
    printf("num=%d",mal(200,500));
}
