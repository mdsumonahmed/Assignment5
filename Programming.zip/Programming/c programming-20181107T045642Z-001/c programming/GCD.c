#include<stdio.h>
int main()
{
    int m,n,i,GCD;
    printf("enter any two number=:");
    scanf("%d %d",&m,&n);

    for(i=2;i<=m && i<=n;i++)
    {
        if(n%i==0 && m%i==0)
        {
            GCD=i;

        }
    }
    printf("%d",GCD);


}
