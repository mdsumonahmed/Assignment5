#include<stdio.h>
int a=10;
int b=15;
int c;
int main()
{
    printf("%d",a);
}
int add()
{
    c=a+b
    printf("sum is %d",c);
}
