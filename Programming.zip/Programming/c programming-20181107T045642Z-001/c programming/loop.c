#include<stdio.h>
int main()
{
    int i;
    for(i=1;i>=100000;i++);

    printf("i\t");

    return 0;
}
