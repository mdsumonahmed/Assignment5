#include<stdio.h>
int main()
{
    int i,n,count=0;
    printf("enter n=");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        printf("it's i=%d\n",i);
        count=count+i;
    }
    printf("%d\n",count);

    return 0;
}
