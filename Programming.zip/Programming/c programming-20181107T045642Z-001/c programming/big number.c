#include<stdio.h>
int main()
{
    int  a,b,c;

    printf("enter any three number=");
    scanf("%d %d %d",&a,&b,&c);

    if(a>b && a>c)
        printf("big number is=%d\n",a);

    else if(b>a && b>c)
        printf("big numner is=%d\n",b);

    else if(c>a && c>b)
        printf("big number is=%d\n",c);

    else if(a==b && b==c && c==a)
        printf("number are equal");

    else if(a==b || b==c || a==c)
        printf("two number are equal");


    return 0;


}
