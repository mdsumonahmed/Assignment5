#include<stdio.h>
int recursive(int count)
{
   if(count ==5)
   {
       return;
   }

     char *a="Hello graph-ai";
       printf("%s\n",a);
       recursive(count+1);
}
void main()
{
    recursive(0);
}

