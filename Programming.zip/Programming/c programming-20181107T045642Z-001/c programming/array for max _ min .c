#include<stdio.h>
void main()
{
    int num[100],i,n;
    printf("how many numbers :");
    scanf("%d",&n);
    for(i=0;1<n;i++)
        {
        scanf("%d",&num[i]);
        }
    int max = num[0];
    for(i=1;i<n;i++)
        {
        if(max<num[i])
            max=num[i];
        printf("max number is %d\n",max);
        }

}
