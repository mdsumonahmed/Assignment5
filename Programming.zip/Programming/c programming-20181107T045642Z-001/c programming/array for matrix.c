#include<stdio.h>
void main()
{
    int A[10][10],B[10][10],C[10][10];
    int i,j,row,col;
    printf("Enter the number of row and col");
    scanf("%d %d",&row,&col);
    for(i=0;i<row;i++){
        for(j=0;j<col;j++)
        {
            printf("A[%d][%d]=",i,j);
            scanf("%d",&A[i][j]);
        }
        printf("\n");
    }

    for(i=0;i<row;i++){
        for(j=0;j<col;j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");
    }

    for(i=0;i<row;i++){
        for(j=0;j<col;j++)
        {
            printf("B [%d][%d]=",i,j);
            scanf("%d",&B[i][j]);
        }
        printf("\n");
    }
    for(i=0;i<row;i++){
        for(j=0;j<col;j++)
        {
            printf("%d ",B[i][j]);
        }
        printf("\n");
    }
    for(i=0;i<row;i++){
        for(j=0;j<col;j++)
        {
            C[i][j]=A[i][j]+B[i][j];
        }
    }

    printf("matrix A+B\n");
    for(i=0;i<row;i++){
            printf("\n");
        for(j=0;j<col;j++)
        {
            printf("%d\t",C[i][j]);
        }
    }
}
