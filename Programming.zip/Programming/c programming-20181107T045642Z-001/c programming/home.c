
#include<stdio.h>
int main()
{
    int sumon,shipon,shuvo,polash,sobuj,ashik,kiyas,babu,koushik;
    int submit;
    float market,millrate,totalmill,millprice;

    sumon=2+2+2+2+2+3+2+2;
    submit=500;
    printf("sumon mill = %d\t",sumon);
    printf("sumon submit = %d",submit);

    printf("\n");
    shipon=2+2+0+1+1+2;
    submit=500;
    printf("shipon mil = %d\t",shipon);
    printf("shipon submit = %d\t",submit);

    printf("\n");
    shuvo=2+2+2+2+1+1+1+2;
    submit=1000;
    printf("shuvo mil = %d\t",shuvo);
    printf("shuvo submit = %d\t",submit);

    printf("\n");
    polash=2+2+2+1+1+1+1+1;
    submit=1000;
    printf("polash mil = %d\t",polash);
    printf("polash submit = %d\t",submit);


    printf("\n");
    kiyas=2+2+2+1+0+1+0;
    submit=1000;
    printf("kiyas mil = %d\t",kiyas);
    printf("kiyas submit = %d\t",submit);

    printf("\n");
    babu=2+2+2+2+1+2+1+2;
    submit=1500;
    printf("babu mil = %d\t",babu);
    printf("babu submit = %d\t",submit);

    printf("\n");
    koushik=2+0+2+1+2+1+2+2+3;
    submit=1000;
    printf("koushik mil = %d\t",koushik);
    printf("koushik submit = %d\t",submit);

    printf("\n\n\t");
    totalmill=sumon+shipon+shuvo+polash+sobuj+ashik+kiyas+babu+koushik;
    printf("total mill = %f\t ",totalmill);


    market=270+433+930+83+452+117+390+1340+230+75;
    printf("total market = %f\t ",market);

    millrate=market/totalmill;
    printf("Mill Rate = %f \t \n",millrate);

    millprice=sumon*millrate;
    printf("sumon mill price = %f\n",millprice);

    millprice=shipon*millrate;
    printf("shipon mill price = %f\n",millprice);

    millprice=shuvo*millrate;
    printf("shuvo mill price = %f\n",millprice);

    millprice=polash*millrate;
    printf("polash mill price = %f\n",millprice);

    millprice=sobuj*millrate;
    printf("sobuj mill price = %f\n",millprice);

    millprice=ashik*millrate;
    printf("ashik mill price = %f\n",millprice);

    millprice=kiyas*millrate;
    printf("kiyas mill price = %f\n",millprice);

    millprice=babu*millrate;
    printf("babu mill price = %f\n",millprice);

    millprice=koushik*millrate;
    printf("koushik mill price = %f\n",millprice);


getchar();
}


