#include<stdio.h>
int arr[20];
int fibo(long long int n)
{
if(n==0 || n==1)
{
    return 1;
}
else{
    if(arr[n]==0)
    {
        arr[n] = fibo(n-1) + fibo(n-2);
        return arr[n];
    }

}
}
void main()
{
    printf("%d\n",fibo(40));
}
