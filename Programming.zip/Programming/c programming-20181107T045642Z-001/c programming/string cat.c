#include<stdio.h>
void main()
{
    char str1[]="my name is";
    char str2[]=" sumon ahmed";

    strcat(str1,str2);
    printf("%s",str1);

    getch();

}
