#include<stdio.h>
int main()
{
    int A[10][10],Row,Col,j,i,uppersum=0,lowersum=0;
    printf("enter row and col for matrix :");
    scanf("%d %d",&Row,&Col);
    for(i=0;i<Row;i++){
        for(j=0;j<Col;j++)
        {
            printf("A[%d][%d]=",i,j);
            scanf("%d",&A[i][j]);
        }
    }
    for(i=0;i<Row;i++){
        for(j=0;j<Col;j++)
        {
            if(i<j)
            {
                uppersum=uppersum+A[i][j];
            }
            if(i>j)
            {
                lowersum=lowersum+A[i][j];
            }
        }
    }
    printf("uppersum=%d\n",uppersum);
    printf("lowersum=%d",lowersum);
}
