#include<stdio.h>
int main()
{
    double a,b,c,x1,x2,d;

    printf("enter any three number=");
    scanf("%lf %lf %lf",&a,&b,&c);

    d=sqrt(b*b-4*a*c);
    x1=(-b+d)/2*a;
    x2=(-b-d)/2*a;

    printf("%lf\n",x1);
    printf("%lf\n",x2);

    return 0;
}
