#include<stdio.h>
int main()
{
    char source[]="c programming";
    char target[20];
    strcpy(target,source);

    printf("source=%s\n",source);
    printf("target=%s",target);

    return 0;
}
