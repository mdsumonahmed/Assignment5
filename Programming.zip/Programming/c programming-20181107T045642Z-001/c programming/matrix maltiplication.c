#include<stdio.h>
void main()
{
    int first[10][10],second[10][10],result[10][10],sum=0;
    int r1,c1,r2,c2,i,j,k;

    printf("enter row and col for first matrix \n");
    scanf("%d %d",&r1,&c1);

    printf("enter row and col for second matrix \n");
    scanf("%d %d",&r2,&c2);
    ///first matrix;
    for(i=0;i<r1;i++){
        for(j=0;j<c1;j++)
            scanf("%d",&first[i][j]);
    }
    ///second matrix;
    for(i=0;i<r2;i++){
        for(j=0;j<c2;j++)
            scanf("%d",&second[i][j]);
    }
    ///first matrix;
    printf("\n \n first matrix \n");
    for(i=0;i<r1;i++){
         printf("\t");
        for(j=0;j<c1;j++)
            printf("%d",&first[i][j]);
    }
     ///first matrix;
     printf("\n \n second matrix \n");
    for(i=0;i<r2;i++){
        printf("\t");
        for(j=0;j<c2;j++)
            scanf("%d",&second[i][j]);
    }
    return 0;
}
