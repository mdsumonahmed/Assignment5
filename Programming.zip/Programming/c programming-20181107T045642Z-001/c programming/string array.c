#include<stdio.h>
int main()
{
    char s1[20];
   gets(s1);

    printf("s1=%s",s1);
}
