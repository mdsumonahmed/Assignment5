#include<stdio.h>
void main()
{
    int num[]={10,15,30,20,50,40};
    int value,pos=-1,i;
    printf("Enter the value :");
    scanf("%d",&value);
    for(i=0;i<7;i++)
    {
        if(value==num[i])
        {
            pos=i+1;
            break;
        }
    }
     if(pos==-1)
        {
        printf("The number is not found");
        }
        else{
            printf("Value is %d",pos);
        }
}
