#include<stdio.h>
int main()
{
    int a[10],sum=0,i;
   printf("ennter 5 number \n");
   for(i=0;i<=5;i++)
   {
       scanf("%d",&a[i]);
   }

    for(i=0;i<=5;i++){
        sum=sum+a[i];
    }
    printf("%d\n",sum);
    printf("avarage %lf\n",(float)sum/5);

}
