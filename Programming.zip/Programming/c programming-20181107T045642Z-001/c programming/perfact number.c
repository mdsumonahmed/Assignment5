#include<stdio.h>
int main()

{
    while(1){
    int n,sum=0,i;
    printf("Enter the last number");
    scanf("%d",&n);
    printf("1+2+3+.......+%d\n",n);
    for(i=1;i<=n;i++)
    {
        printf("+%d ",i);
        sum=sum+i;
    }
    printf("=%d\n",sum);

    getch();
}
}
