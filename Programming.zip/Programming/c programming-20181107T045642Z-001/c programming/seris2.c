#include<stdio.h>
int main()

{
    int n1,n2,a=1,b=2,count=0;
    printf("Enter n1 and n2 :");
    scanf("%d %d",&n1,&n2);

    while(a<=n1 && a<=n2)
    {
        count=count+a*b;
        a=a+1;
        b=b+1;
    }
    printf("%d\n",count);

    getch();
}

/*
{
    int n1,n2,a,b,count=0;
    printf("Enter n1 and n2");
    scanf("%d %d",&n1,&n2);

    for(a=1 && b=2; a<=n1 && b<=n2; a=a+1 && b=b+1)
    {
        count=count+a*b;
        printf("%d\n",count);
    }
    getch();
}*/
