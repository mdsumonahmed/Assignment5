#include<stdio.h>
void main()
{
    int row,col,n;
    scanf("%d",&n);
    for(row=1;row<=n;row++){
        for(col=1;col<=n-row;col++)
            {
            printf(" ",col);
            }
        for(col=1;col<=2*row-1;col++)
        {
            printf("%d",col);
        }
        printf("\n");
    }
}
