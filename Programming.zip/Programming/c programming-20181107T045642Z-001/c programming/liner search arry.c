#include<stdio.h>
int main()
{
    int num[]={10,20,15,40,80,30};
    int valu,pos=-1,i;
    printf("enter any number :");
    scanf("%d",&valu);
    for(i=0;i<7;i++)
    {
        if(valu==num[i]){

            pos=i+1;
            break;
        }
    }
    if(pos==-1)
        printf("not found");
    else
        printf("the positions is %d\n",pos);

    return 0;
}
