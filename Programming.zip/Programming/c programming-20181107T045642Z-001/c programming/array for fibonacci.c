#include<stdio.h>
void main()
{
    int a[30],i,n;
    printf("how many numbers : ");
    scanf("%d",&n);
    a[0]=0;
    a[1]=1;
    for(i=2;i<n;i++)
    {
        a[i]=a[i-1]+a[i-2];
    }
    for(i=0;i<n;i++)
    {
        printf("%d ",a[i]);
    }
}
