#include<stdio.h>
int main()
{
    int first,second,fibo,n,i;
    scanf("%d",&n);
    for(i=0;i<=n;i++) {
    fibo=first+second;
    first=second;
    second=fibo;
    printf("%d\n",fibo);
    }
}

