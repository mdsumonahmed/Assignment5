#include<stdio.h>
int main()
{
    int num;
    printf("enter any number=");
    scanf("%d",&num);

    if(num<=100 && num>=80)
        printf("Grate point=A+");

    else if(num<=80 && num>=60)
        printf("Grate point=B");

    else if(num<=60 && num>=40)
        printf("Grate point=C");

    else
        printf("Fail");

        return 0;

}
