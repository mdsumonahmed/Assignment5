#include<stdio.h>
void main()
{
int i, num,rem=0,sum=0;
printf("enter any number:");
scanf("%d",&num);
for(i=1;i<=num;i++){
rem=num%i;
if (rem==0)
{
sum=sum+i;

}
if(sum==num)

printf("perfect")

else
{
printf("not perfect")
}
