#include<stdio.h>
void main ()
{
    int a,b,c;
    printf("enter any two number for multi :");
    scanf("%d %d",&a,&b);

    c=a*b;
    printf("%d",c);
}
