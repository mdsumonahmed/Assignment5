#include<stdio.h>
int main()
{
    int num1,num2,n1,n2,count,GCD,LCM;
    printf("Enter two number :");
    scanf("%d %d",&num1,&num2);

    n1=num1;
    n2=num2;

    while(n2 !=0){
        count = n1%n2;
        n1 = n2;
        n2 = count;
    }
    GCD = n1;
    LCM = (num1*num2)/GCD;

    printf("gcd=%d\n",GCD);
    printf("lcm=%d\n",LCM);

    return 0;
}
