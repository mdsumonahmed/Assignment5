#include<stdio.h>
void main()
{
    int n=pow(10,2),v;
    printf("%d",n);
    int i,j;


    for(i=0;i<=n;i++)
        {
        printf("%d\n",i);
        }
        for(i=0;i<n;i++) {
        for(j=0;j<=i;j++)
        {
            if(sqrt(j)==i)
            printf("%d\n",j);
            break;
        }
        }
}



