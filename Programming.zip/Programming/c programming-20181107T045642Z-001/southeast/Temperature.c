#include<stdio.h>
#include<stdlib.h>
int main()
{

printf("%d",CHAR_MAX);
    float calsius,fahrenhit;
    printf("enter temperature in calsius = ");
    scanf("%f",&calsius);
    fahrenhit = (calsius*9/5)+32;
    printf("Today temperature in fahrenhit %.2f F",fahrenhit);
    return 0;
}
