#include<stdio.h>
#include<stdlib.h>

int main()
{
//    int a = findBigger(20,15);
//    printf("%d", a);
//
//    a = findBigger(50,a);
//    printf("%d", a);
//
//    a = findBigger(10,a);
//    printf("%d", a);
//
//    printf("%d",a);


    printf("\n");
    int bigger = findBigger(60,findBigger(30,findBigger(10,20)));
    printf("%d",bigger);
    return 0;
}

int findBigger(int a,int b){

    return a>b ? a:b;
}
