#include<stdio.h>
#include<stdlib.h>

int prime(int x)
{
    int i,flag = 0;
    for(i=2;i<x;i++){
        if(x%i==0){
            flag = 1;
        }
        return flag;
    }
}

int odd(int x)
{
    if(x%2==0){
        return 0;
    }
    else{
    return 1;
    }
}
int main()
{
   int i,n,count = 0;
   printf("enter any integer number\n");
   scanf("%d",&n);

   if(prime(n)==0){
    printf("number is prime\n");
   }
   else {
    printf("number is Composite\n");
   }

   if(odd(n)==0){
    printf("odd\n");
   }
   else{
    printf("even\n");
   }
   return 0;
}
