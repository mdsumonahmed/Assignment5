#include<stdio.h>
#include<stdlib.h>
# define my_sizeof 10

char word[my_sizeof];
int main()
{

 int i,j,flag = 0;
 printf("Enter a word\n");
 scanf("%[^\n]%*c",&word);
 int len = strlen(word);
 for(i=0, j=len-1; i<len/2; i++,j--)
 {
    if(word[i] != word[j])
        {
            flag = 1;
        }
 }

 if(flag == 0)
 printf("word is palindrom");

 else
 printf("word is not palindrom");
return 0;
}
