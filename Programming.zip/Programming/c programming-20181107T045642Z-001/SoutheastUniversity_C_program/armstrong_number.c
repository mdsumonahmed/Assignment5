#include<stdio.h>
#include<stdlib.h>

int main()
{
    int tp,number,r,sum = 0;
    printf("enter your number\n");
    scanf("%d",&number);

    tp = number;
    while(tp != 0){
        r = tp % 10;
        sum = sum + r*r*r;
        tp = tp/10;
    }

    if(number == sum){
        printf("Number is Armstrong");
    }
    else
        printf("number is not Armstrong");

    return 0;

}
