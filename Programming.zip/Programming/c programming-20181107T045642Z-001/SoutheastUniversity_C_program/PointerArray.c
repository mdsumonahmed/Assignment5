#include<stdio.h>
#include<stdlib.h>
const int x = 5;
int main(){
    int arr[]={10,20,30,40,50};
    int *ptr,i;
    ptr = arr;
    i=0;

    while(ptr<=&arr[x-1]){
        printf("arr[%d] = %x\n",i,ptr);
        printf("arr[%d] = %d\n",i,*ptr);

        ptr++;
        i++;
    }

    return 0;
}
