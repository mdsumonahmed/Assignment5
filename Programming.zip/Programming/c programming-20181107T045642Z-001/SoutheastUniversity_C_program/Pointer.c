
#include<stdio.h>
#include<stdlib.h>
int main()
{

   int x=5,y=10,temp;
   int *ptr1,*ptr2;
   ptr1=&x;
   ptr2=&y;

   temp = *ptr1;
   *ptr1 = *ptr2;
   *ptr2 = temp;
    printf("memory location of a %d\n",*ptr2);


    const char *c = "5";
    int d = atol(c);
    printf("%d\n", d);
 return 0;
}
