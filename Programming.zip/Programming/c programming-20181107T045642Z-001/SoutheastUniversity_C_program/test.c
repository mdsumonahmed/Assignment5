
#include <stdio.h>
#include<stdlib.h>

int main()
{
   char str[25];
   int i, j, flag = 0;
   printf("Enter the string: ");
   scanf("%s",str);

   for(i=0;i<=strlen(str);i++){
      if(str[i]>=65&&str[i]<=90)
         str[i]=str[i]+32;
   }

   int len = strlen(str);
    for(i = 0, j = len - 1; i < len/2; i++, j--)
    {
        if(str[i] != str[j])
            flag = 1;
    }
    if(flag == 0)
        printf("Palindrom");
    else
        printf("Not Palindrom");

    return 0;
}
