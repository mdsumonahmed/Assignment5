#include <stdio.h>
#include <stdlib.h>

int main()
{
     float a = 23.7654;
     printf("%7.3f",a);
    return 0;
}
