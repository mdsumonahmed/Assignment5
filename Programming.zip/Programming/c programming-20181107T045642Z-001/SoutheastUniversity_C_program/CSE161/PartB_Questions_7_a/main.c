#include <stdio.h>
#include <stdlib.h>

int main()
{
    float num1,num2,num3,num4;
    printf("enter number 1\n");
    scanf("%f",&num1);

    printf("enter number 2\n");
    scanf("%f",&num2);

    printf("enter number 3\n");
    scanf("%f",&num3);

    printf("enter number 4\n");
    scanf("%f",&num4);

    if(num1>num2 && num1>num3 && num1>num4){
        printf("%f is max number",num1);
    }

    else if(num2>num1 && num2>num3 && num2>num4){
        printf("%f is max number",num2);
    }

    else if(num3>num1 && num3>num2 && num3>num4){
        printf("%f is max number",num3);
    }

    else
    {
        printf("%f is max number",num4);
    }

    return 0;
}
