#include <stdio.h>
#include <stdlib.h>

int func1()
{
    printf("0");
    return 01;
}
void func2()
{
    int x;
    x=func1();
    printf("1");
}
int main()
{
    func2();
    printf("0");
    return 10;
}
