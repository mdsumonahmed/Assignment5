#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,n,flag=0;
    printf("enter any intager number\n");
    scanf("%d",&n);
    for(i=2;i<n;i++)
    {
        if(n%i==0)
        {
            flag++;
            break;
        }
    }
    if(flag==0){
            printf("%d is Prime number",n);
    }
    else
        printf("%d number is Composite",n);
    return 0;
}
