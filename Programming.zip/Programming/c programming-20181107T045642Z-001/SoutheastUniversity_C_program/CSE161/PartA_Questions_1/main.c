#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 5;
    int b = 3;
    int c = a+b;
    printf("%d",c%6);

    return 0;
}
