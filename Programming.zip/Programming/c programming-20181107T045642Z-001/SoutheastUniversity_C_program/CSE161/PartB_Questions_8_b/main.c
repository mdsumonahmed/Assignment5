#include <stdio.h>
#include <stdlib.h>
float num1,num2;
int type;
double result;

double MyAdd(float x,float y)
{
    double z;
    z = x+y;
    return z;
}

double MySub(float x,float y)
{
    double z;
    z = x-y;
    return z;
}

double MyMultiply(float x,float y)
{
    double z;
    z = x*y;
    return z;
}

double MyDiv(float x,float y)
{
    double z;
    z = x/y;
    return z;
}
int main()
{

    printf("Enter any 2 number \n");

    printf("Number 1 : \n");
    scanf("%f",&num1);

    printf("Number 2 : \n");
    scanf("%f",&num2);

    printf("What type of calculation do you want \n");
    printf("For adds enter 1 \n");
    printf("For Subtracts enter 2 \n");
    printf("For Multiplies enter 3 \n");
    printf("For Divides enter 4 \n");

    scanf("%d",&type);
    switch(type)
    {
        case 1:
        result = MyAdd(num1,num2);
        printf("Result = %.lf",result);
        break;

        case 2:
        result = MySub(num1,num2);
        printf("Result = %.lf",result);
        break;

        case 3:
        result = MyMultiply(num1,num2);
        printf("Result = %.lf",result);
        break;

        case 4:
        result = MyDiv(num1,num2);
        printf("Result = %.lf",result);
        break;

        default:
        printf("error");
    }


    return 0;
}
