#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c,d;
    float cal1,cal2;
    double result;

    cal1 = c/pow(a,d);
    cal2 = d*(a*b+pow(c,2))/a-b;
    result= cal1+cal2;
    return 0;
}
