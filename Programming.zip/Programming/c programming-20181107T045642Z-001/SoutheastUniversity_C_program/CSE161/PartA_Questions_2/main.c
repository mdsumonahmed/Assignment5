#include <stdio.h>
#include <stdlib.h>

int main()
{
   int x;
   x=17/3;
   printf("%d",x);
   return 0;
}
