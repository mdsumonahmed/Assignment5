#include <stdio.h>
#include<stdlib.h>
#include <string.h>
double gradeToPoint(char str[2]){
    if (strcmp(str, "A+") == 0)
        return 4.00;
    else if (strcmp(str, "A") == 0)
        return 3.75;
    else if (strcmp(str, "A-") == 0)
        return 3.50;
    else if (strcmp(str, "B+") == 0)
        return 3.25;
    else if (strcmp(str, "B") == 0)
        return 3.00;
    else if (strcmp(str, "B-") == 0)
        return 2.75;
    else if (strcmp(str, "C+") == 0)
        return 2.50;
    else if (strcmp(str, "C") == 0)
        return 2.25;
    else if (strcmp(str, "D") == 0)
        return 2.00;
    else
       return 0.00;
}
int main() {
    int n, creditHours, sumOfCreditHours = 0;
    char grade[2];
    double sumOfGradePoint = 0.00;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &creditHours);
        scanf("%s", grade);
        sumOfCreditHours += creditHours;
        sumOfGradePoint += (gradeToPoint(grade)*creditHours);
    }
    printf("%.2lf", sumOfGradePoint/sumOfCreditHours);
    return 0;
}
