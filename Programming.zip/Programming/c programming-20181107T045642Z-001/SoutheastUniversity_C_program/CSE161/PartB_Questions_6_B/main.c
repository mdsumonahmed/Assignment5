#include <stdio.h>
#include <stdlib.h>

int main()
{
    int year;
    float result;

    printf("enter any year\n");
    scanf("%d",&year);
    result=year%4;

    if(result==0)
    {
        printf("%d year is leap year\n",year);
    }

    else
    {
        printf("%d year is not leap year\n",year);
    }
    return 0;
}
