#include<stdio.h>
#include<stdlib.h>

int main()
{
    int a = 0, b = 1, c = 1, fibo, n;
    printf("Enter your Range\n");
    scanf("%d",&n);

    while(c<=n)
    {
        if(c<=1)
            fibo = c;

        else{
            fibo = a+b;
            a = b;
            b = fibo;
        }
        printf("%d ",fibo);
        c++;
    }
    return 0;
}

