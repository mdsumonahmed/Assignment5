#include<stdio.h>
#include<stdlib.h>

int main()
{
    int arr[13];
    int i,n,sw,count = 0;
    scanf("%d",&n);

    for(i = 0; i<n; i++){
        scanf("%1d",&arr[i]);
    }

    for(i = 0; i<n; i++){
    printf("%d ", arr[i]);
    }
    printf("\n");

    for(i = 0; i<n; i++){
        sw = arr[i];
        for(int j = 2; j<=sw; j++){

        if(sw%j == 0)
            count = 1;
            break;
        }
        if(count==0)
        printf("\t %d",sw);
    }

    return 0;
}
