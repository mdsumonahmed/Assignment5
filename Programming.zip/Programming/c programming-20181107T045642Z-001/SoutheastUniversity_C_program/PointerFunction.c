#include<stdio.h>
#include<stdlib.h>
#include<time.h>

double Average(int *array,int size)
{
    int i,sum=0;
    double avg;
    for(i = 0; i<size; i++){
        sum += array[i];
    }

    avg = sum/size;

    return avg;
}
int main()
{
    int arr[5] = {1000, 2, 3, 17, 50};
    double avg;

    avg = Average(arr,5);
    printf("average = %lf\n",avg);
    return 0;
}
