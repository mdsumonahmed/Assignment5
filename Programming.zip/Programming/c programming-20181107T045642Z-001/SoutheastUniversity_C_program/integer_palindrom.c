#include<stdio.h>
#include<stdlib.h>

int main()
{
    int number, tmp, r, sum = 0;
    printf("enter integer number\n");
    scanf("%d",&number);

    tmp = number;

    while(tmp != 0){
        r = tmp%10;
        sum = sum*10+r;
        tmp = tmp/10;
    }

    if(number==sum)
        printf("number is palindrom");

    else
        printf("number is not palindrom");
    return 0;
}

