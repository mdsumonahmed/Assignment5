#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
    char name1[30] = "madam";
    char name2[30];
    int i = 0, len = 0, j;

    while(name1[i] !='\0')
    {
        i++;
        len++;
    }

    for(j=0,i=len-1; i>=0; i--,j++)
    {
        name2[j] = name1[i];
    }
    name2[j] ='\n';

    printf("name1 = %s\n",name1);
    printf("name2 = %s",name2);


    if(bool==true)
        printf("palindrom");

    else
        printf("not palindrom");

    return 0;
}
