#include<stdio.h>
#include<stdlib.h>
# define my_sizeof(type) ((char *)(&type+1)-(char*)(&type))
int i,n;
int even = 0, odd = 0;
void findEvenOdd(int length,int data[])
{
    //printf("size of array %d\n",length);
    for(i=0; i<length; i++)
    {
        if(data[i] %2 == 0){
          even = even + data[i];
        }

        if(data[i] %2 != 0){
          odd = odd + data[i];
        }
    }

    if(even>odd)
        printf("yes");

    else
        printf("No");

    return 0;
}
int main()
{
    int array[] = {1,2,3,4,5,6,7,8,9,10};
    int size = my_sizeof(array)/my_sizeof(array[0]);
    findEvenOdd(size,array);
    //int even = 0, odd = 0;
    //int i,n;

    //printf("%d\n",size);

    /*for(i = 0; i<size; i++){

        if(array[i] % 2 == 0){
            //printf("even number is %d \n", array[i]);
            even = even+ array[i];
        }
        if(array[i] % 2 != 0){
            //printf("odd number is %d \n",array[i]);
            odd = odd+ array[i];
        }
    }

    printf("sum of even = %d \n",even);

    printf("sum of odd = %d \n", odd);
    */


    return 0;

}
