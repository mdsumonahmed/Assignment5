#include<stdio.h>
int main()
{
   int sum=0,i,n;
   printf("enter any number");
    scanf("%d",&n);

   for(i=2;i<=n;i=i+2){
     sum=sum+i;
   }
   printf("%d",sum/i);
    return 0;
}

