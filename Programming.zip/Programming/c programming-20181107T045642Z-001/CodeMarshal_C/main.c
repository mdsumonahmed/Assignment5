#include <stdio.h>
#include <stdlib.h>

int main()
{
    int X,Y,Z,studentX,studentY,totalStudent;
    X = 100;
    Y = 100;
    Z = 50;

    studentX = X-Z;
    studentY = Y-Z;

    totalStudent = studentX+studentY+Z;
    printf("\n%d",totalStudent);
    return 0;
}
