#include<stdio.h>
#include<stdlib.h>

int main() {
    float A,B,C,Avg;
    scanf("%f %f %f",&A,&B,&C);
    Avg = ((A*2)+(B*3)+(C*5))/(2+3+5);
    printf("MEDIA = %.1f\n",Avg);
    return 0;
}
