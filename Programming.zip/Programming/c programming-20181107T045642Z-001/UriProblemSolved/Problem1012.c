#include <stdio.h>

int main() {

    double A,B,C;
    scanf("%lf %lf %lf",&A,&B,&C);
    double Triangle = A*C*1/2;
    double Circulo = 3.14159*pow(C,2);
    double Trapezium = C*1/2*(A+B);
    double Square = pow(B,2);
    double Retangulo = A*B;

    printf("TRIANGULO: %.3lf\n",Triangle);
    printf("CIRCULO: %.3lf\n",Circulo);
    printf("TRAPEZIO: %.3lf\n",Trapezium);
    printf("QUADRADO: %.3lf\n",Square);
     printf("RETANGULO: %.3lf\n",Retangulo);
    return 0;
}
