#include<stdio.h>
int main()
{

printf("1004");
return 0;
}

