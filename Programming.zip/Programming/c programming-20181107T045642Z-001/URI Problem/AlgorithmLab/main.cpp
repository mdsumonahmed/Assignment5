#include<bits/stdc++.h>
using namespace std;
int main(){

    clock_t t1 = clock();
    for(long long i = 0; i< 3000000000; i++){


    }

    clock_t t2 = clock();
    clock_t t = (t2-t1)/CLOCKS_PER_SEC;
    cout<<"Total time "<< t <<"Sec"<<endl;

return 0;
}
