#include<stdio.h>
#include<stdlib.h>
int main()
{

printf("problem 10");
return 0;
}

