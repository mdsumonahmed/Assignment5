#include<stdio.h>
#include<stdlib.h>
#include <limits.h>
#include <float.h>
int main()
{
    long int a = 10101010121030;
    printf("CHAR_MAX :   %d\n", CHAR_MAX);
    printf("long max :  %ld\n",(long) LONG_MAX);

    printf("LONG_MAX    :   %ld\n", (long) LONG_MAX);
    printf("int max : %d\n",INT_MAX);

    printf("valu : %ld\n",a);
    return 0;
}
