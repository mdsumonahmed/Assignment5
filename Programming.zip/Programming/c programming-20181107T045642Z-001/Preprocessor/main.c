#include <stdio.h>
#include <stdlib.h>
#include "info.h"
int main()
{
    printf("%s\n",name);
    printf("%d\n",age);
    return 0;
}
