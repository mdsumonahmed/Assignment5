#include<stdio.h>
#include<stdlib.h>

int bigger(int a,int b,int c)
{
    int va = a;
    int vb = b;
    int vc = c;
    if(va>vb){
        if(va>vc){
            printf("Bigger number is %d\n",va);
        }
        else{
            printf("Bigger number is %d\n",vc);
        }
    }
    else if(vb>vc){
        printf("Bigger number is %d \n",vb);
    }
    else{
        printf("Bigger number is %d",vc);
    }
}



int main()
{
    int a,b,c;
    scanf("%d%d%d",&a,&b,&c);
    bigger(a,b,c);
    return 0;
}
