print(10)
print("hello world")