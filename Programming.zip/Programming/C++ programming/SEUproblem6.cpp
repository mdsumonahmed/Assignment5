#include<bits/stdc++.h>
using namespace std;


int main(){

        /*int number = 0,
        digits = 0,
        position = 0,
        result = 0;

    cout << "Enter a number: ";
    cin >> number;

    cout << "Enter a digit position:";
    cin >> position;
*/
    int n,number;
    int result;
    cin>>n;
    number = pow(6,n);

    number = number / pow(10,0);
    result = number % 10;

    cout << result <<'\n';
return 0;
}
