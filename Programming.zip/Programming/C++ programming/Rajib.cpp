#include<bits/stdc++.h>
using namespace std;

int main()
{
    int a, b, m, cnt, t;

    cin >> t;
    for (int i=0; i<t; i++)
    {
        cnt = 0;
        cin >> a >> b >> m;

        if (__gcd(a, b) == 1)
            cnt++;
        for (int j=1; j<=m; j++)
        {
            if (__gcd(a+j, b+j)==1)
                cnt++;
        }
    cout << "Case " << i+1 << ": " << cnt << endl;
    }
}
