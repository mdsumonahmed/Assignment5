#include<bits/stdc++.h>
using namespace std;
#define mx 1001
vector<int>graph[mx];
bool vis[mx];
int dis[mx];

void reset(int n){
    for(int i=1; i<=n; i++){
        graph[i].clear();
        vis[i]=false;
        dis[i]=0;
    }

}
void bfs(int s){
    queue<int> Q;
    vis[s]=1;
    dis[s]=0;
    Q.push(s);
    while(!Q.empty()){
        int node = Q.front();
        Q.pop();
        for(int i=0; i<graph[node].size(); i++){
            int next = graph[node][i];
            if(vis[next]==0){
                vis[next]=1;
                dis[next]=dis[node]+6;
                Q.push(next);
            }
        }
    }

}
int main(){
    int q;
    cin>>q;
    for(int i=0; i<q; i++){

    int n,m,s;
    cin>>n>>m;
    for(int i=1; i<=m; i++){
        int u,v;
        cin>>u>>v;
        graph[u].push_back(v);
        graph[v].push_back(u);
    }
    cin>>s;
    bfs(s);
    for(int i=1; i<=n; i++){
        if(i==s)
            cout<<" ";
        else if(vis[i]==0)
            cout<<"-1 ";
        else
            cout<<dis[i]<<" ";
    }
    cout<<endl;
    reset(n);
   }
    return 0;
}
