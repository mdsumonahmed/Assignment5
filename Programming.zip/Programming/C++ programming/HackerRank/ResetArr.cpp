
#include<bits/stdc++.h>
using namespace std;
int main(){
    vector<int> myvector;
    myvector.push_back(1);
    myvector.push_back(2);
    myvector.push_back(3);

    myvector.clear();

}
