#include<bits/stdc++.h>
using namespace std;
int main()
{
    cout<<"Welcome to ICPC Dhaka Regional Online Preliminary Contest, 2019"<<endl;
return 0;
}
