#include<iostream>
using namespace std;


class workshop{

    public:
    int a;
    int b;
    int add();
    //string display();
};

int workshop::add(){
    return a+b;
};

  int main(){
    workshop ob;
    ob.a = 10;
    ob.b = 20;
    cout<<ob.add()<<endl;
    return 0;
}
