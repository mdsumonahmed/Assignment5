#include<bits/stdc++.h>
using namespace std;
int main()
{
    vector<int>A[10];
    /*A[0].push_back(1);
    A[1].push_back(1);
    A[2].push_back(1);
    A[3].push_back(1);
    A[4].push_back(1);
    A[0].push_back(1);*/
    for(int i=0;i<5;i++){
        A[i].push_back(i);
    }

        for(int i=0; i<5;i++){
            for(int j=0; j<5;j++){
            cout<<A[i][j]<<" ";
        }cout<<endl;
        }
    return 0;
}
