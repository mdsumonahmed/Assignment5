#include<bits/stdc++.h>
using namespace std;
int main()

{
    int n,row,col;
    printf("enter row number :");
    scanf("%d",&n);
    for(row=n;row>=1;row--)
    {
        for(col=1;col<=row;col++)
        {
            printf("%d ",col);
        }
        printf("\n");
    }
    return 0;
}


