#include<iostream>
using namespace std;
class workshop{
    public:
    int chair;
    int getstudent();
    void setstudent(int stu);
    private:
    int student;

};
int workshop::getstudent(){
    return student;
}
void workshop::setstudent(int stu){
    student = stu;
}

int main(){
    workshop ob;
    ob.chair=20;
    ob.setstudent(30);
    cout<<"chair of workshop : "<<ob.chair<<endl;
    cout<<"student of workshop : "<<ob.getstudent()<<endl;
}
