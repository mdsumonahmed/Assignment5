#include<bits/stdc++.h>
using namespace std;
int main(){
        int a,b,m,T;

        cin>>T;
        for(int i = 1; i<=T; i++){
            scanf("%d%d%d",&a,&b,&m);
            int pairs = 0;
            for(int i=1; i<=2; i++){
                 int gcd = __gcd(a,b);
                 if(gcd==1){
                 pairs = pairs+1;
                 }

                 a=a+i;
                 b=b+i;
            }

            cout<<"Case "<<i<<": "<<pairs<<endl;

        }
    return 0;
}
