#include<bits/stdc++.h>
using namespace std;

   void bouble_sort(std::array<int,4>arr,int n){
    for(int i=0;i<n;i++)
        {
            for(int j=0;j<n-i-1;j++)

               if(arr[j] < arr[j+1]){
                  swap(arr[j],arr[j+1]);
                  }
            }
    }
int main(){
    int n=4;
    std::array<int,4> A1= {10,20,30,40};
    std::array<int,4> A2= {11,12,13,14};
    std::array<int,4> A3= {21,22,23,24};
    std::array<int,4> B;
    B = A1;
    B = A2;
    B = A3;

    bouble_sort(A1,n);
    for(int i=0; i<4; i++)
            cout <<A1[i] << " ";
   return 0;
}
