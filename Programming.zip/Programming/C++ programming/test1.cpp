#include<iostream>
#include<cstdlib>
//using namespace std;
main(){
    std::string name;
    std::cout<<"How are you"<<std::endl;
    std::cin>>name;

    std::cout<< "I am "+name<<std::endl;

    return EXIT_SUCCESS;
}
