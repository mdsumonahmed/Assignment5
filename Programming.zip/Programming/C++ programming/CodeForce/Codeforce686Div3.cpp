#include<bits/stdc++.h>
using namespace std;
int main(){
    int t,n;
    cin>>t;
    for(int i=0; i<t; i++){
        int p = 1;
        cin>>n;
        int arr[n];
        for(int i=0; i<n; i++){
            arr[i] = p;
            p++;
        }
        for(int i=1; i<n; i++){
            cout<<arr[i]<<" ";
        }
        cout<<"1";
        cout<<endl;

    }

return 0;
}
