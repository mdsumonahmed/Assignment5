#include<bits/stdc++.h>
using namespace std;
void automatize(int sl,string st){
    int length = sl;
    string myStr = st;
    char firstChar,lastChar;

    firstChar = myStr.at(0);
    lastChar = myStr.at(length-1);
    cout<<firstChar<<length-2<<lastChar<<endl;
}
int main(){
    int n,length;
    string myStr;
    cin>>n;
    for(int i = 0; i<n; i++){
    cin>>myStr;
    length = myStr.length();

    if(length>10)
        automatize(length,myStr);
    else
        cout<<myStr<<endl;

    }
    return 0;
}
