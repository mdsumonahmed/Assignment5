#include<bits/stdc++.h>
using namespace std;

int main(){
    int length;

    string word;
    cin>>word;
    length = word.length();

    for(int i=0; i<length; i++){

        if(word[i]>=65 && word[i]<=92)
          {
          word[i]=word[i]+32;
          }

      }

      for(int i=0; i<length; i++){
        if(word.at(i) == 'a'|| word.at(i) == 'e' || word.at(i) == 'i' || word.at(i) == 'o' || word.at(i) == 'u' || word.at(i) == 'y'){
            cout<<"";
        }
        else
            cout<<"."<<word.at(i);
      }

return 0;
}
