#include<bits/stdc++.h>
using namespace std;

void favarate(int arr[],int start, int en){
    while(start<en){
        cout<<arr[start]<<" "<<arr[en]<<" ";
        start++;
        en--;
    }
    if(start==en)
        cout<<arr[start];
        cout<<"\n";
}
int main(){
    int t,n,temp;
    cin>>t;
    for(int i = 0; i<t; i++){
        cin>>n;
        int arr[n];
        for(int i = 0; i<n; i++){
            cin>>arr[i];
        }

        favarate(arr,0,n-1);
    }


    return 0;
}
