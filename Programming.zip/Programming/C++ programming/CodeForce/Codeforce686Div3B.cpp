/*
	author: @Sumon [github, codeforces]
	date: 21 Mar 2021
*/

#include<bits/stdc++.h>
using namespace std;
int main(){
    int t,n,win = -1,wors,minimal;
    cin>>t;
    for(int z=1; z<=t; z++){
        cin>>n;
        int a[n];

        for(int x=0; x<n; x++){
            cin>>a[x];

        }
        for(int i=0; i<n; i++){
            int temp=a[i],wors;
            for(int j=i+1; j<n; j++){

                if(temp == a[j]){
                wors = a[j];
                //cout<<"'"<< wors<<"'";
                a[j] = 0;
                }
                else
                    break;
            }
            if(temp == wors){
            a[i] = 0;
            }
            //cout<<a[i];
        }

     for(int k=0; k<n; k++){

        minimal = a[k];
         for(int y=0; y<n; y++){
            if(a[y]>0 && minimal>=a[y]){
                minimal = a[y];
                win = y+1;
            }

         }

        }

        cout<<win<<endl;
        n=0;
    }


return 0;
}
