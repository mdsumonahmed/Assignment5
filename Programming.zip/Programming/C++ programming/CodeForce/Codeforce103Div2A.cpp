#include<bits/stdc++.h>
using namespace std;

void solved()
{
    int n;
    cin>>n;
    int arr[n];
    int max=INT_MIN, min=INT_MAX, maxIndex, minIndex,minc=0;

    for(int i=0; i<n; i++){
      cin>>arr[i];
      if(arr[i]>max){
        max=arr[i];
        maxIndex=i;
      }
      if(arr[i]<=min){
        min=arr[i];
        minIndex=i;
      }
    }

    if(maxIndex>minIndex)
        cout<<maxIndex-minIndex+n-2;
    else
        cout<<maxIndex-minIndex+n-1;

}
int main(){

solved();
}
