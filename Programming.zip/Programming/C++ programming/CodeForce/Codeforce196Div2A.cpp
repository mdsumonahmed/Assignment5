
#include<bits/stdc++.h>
using namespace std;
int main(){
    int min = INT32_MAX;
    cout<<min;
}
