#include<bits/stdc++.h>
using namespace std;

void oneSmallest(int a,int b){
    cout<<"YES"<<endl;
    cout<<"1 "<<a<<" "<<b<<endl;

}
int main(){
int testCase,x,y,z;
cin>>testCase;
for(int i=0; i<testCase; i++){
scanf("%d %d %d",&x,&y,&z);

if(x==y && x==z)
cout<<"YES"<<"\n"<<x<<" "<<y<<" "<<" "<<z<<endl;

else if(x<y && x<z && y==z)oneSmallest(x,y);
else if(y<x && y<z && x==z)oneSmallest(y,x);
else if(z<x && z<y && x==y)oneSmallest(z,x);

else
    cout<<"NO"<<endl;
}
return 0;
}
