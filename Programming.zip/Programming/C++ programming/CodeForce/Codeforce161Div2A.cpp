#include<bits/stdc++.h>
using namespace std;
int main(){
    int arr[5][5];
    int a,b,c,d,x,y;
    for(int i=0; i<5; i++){
        for(int j=0; j<5; j++){
         cin>>arr[i][j];
         if(arr[i][j]==1){
            a= i+1;
            b= j+1;
         }
        }cout<<endl;
    }

    x=abs(a-3);
    y=abs(b-3);
    cout<<x+y<<endl;

}
