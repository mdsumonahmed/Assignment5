#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n,m,temp=0;
    int intersection;
    cin>>n>>m;

    intersection = (m<n)? m:n;
    cout<<((intersection%2==1)? "Akshat":"Malvika")<<endl;
return 0;
}
