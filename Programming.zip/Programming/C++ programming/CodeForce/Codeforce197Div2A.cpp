#include<bits/stdc++.h>
using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    string number;
    cin>>number;
    int t=number.length()/2+1;
    int arr[t];
    int arr_len = sizeof(arr) / sizeof(arr[0]);
    int j = 0;

    for(int i=0; i<number.length(); i+=2){
        arr[j++] = ((int)number[i])-48;
    }
    sort(arr,arr+t);
    cout<<arr[0];
    for(int i=1; i<t; i++)
        cout<<"+"<<arr[i];
return 0;
}
