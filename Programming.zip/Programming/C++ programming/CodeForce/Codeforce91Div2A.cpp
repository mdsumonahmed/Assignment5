#include<bits/stdc++.h>
using namespace std;

bool check_lucky(int n){
    string c_num="";
    string num = to_string(n);
    for(int i=0; i<num.size(); i++){
        if(num[i] == '4' || num[i] == '7')
            c_num +=num[i];
    }
    if(num == c_num)
        return true;
    else
        return false;
}
int main(){
    int n;
    cin>>n;

    if(check_lucky(n) == true)
        cout<<"YES";
    else if(n%4==0 || n%7==0 || n%44==0 || n%47==0 || n%74==0 || n%77==0)
        cout<<"YES";
    else
        cout<<"NO";
}
