#include<bits/stdc++.h>
using namespace std;
void solve(int a,int b,int c){
    int n;

    n=a+b+c;
    n = max(n, a * b * c);
    n = max(n, a * (b + c));
    n = max(n, (a + b) * c);
    cout<<n;
}
int main(){
    ios_base :: sync_with_stdio(false);
    cin.tie(NULL);
    int a,b,c;
    cin>>a>>b>>c;
    solve(a,b,c);

    return 0;
}
