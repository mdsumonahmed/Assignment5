#include<bits/stdc++.h>
using namespace std;

void solve() {
  string s; getline(cin, s);
  bool letters[26] = {0};
  int c = 0;
  for (int i = 1; i < s.size() - 1; i+=3) {
    int pos = s[i] - 97;
    if (letters[pos] == 0) {
      letters[pos] = 1;
      c++;
    }
  }
  cout << c;
}

int main() {
  ios_base::sync_with_stdio(false); cin.tie(NULL);

  solve();
  return 0;
}
