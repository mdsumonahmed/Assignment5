#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,totalX=0,totalY=0,totalZ=0;
    cin>>n;
    int a[n][3];
    for(int i=0; i<n; i++){
        for(int j=0; j<3; j++){
            cin>>a[i][j];
        }
    }
    for(int i=0; i<n; i++){
        for(int j=0; j<3; j++){
            totalX += a[i][0];
            totalY += a[i][1];
            totalZ += a[i][2];
        }
    }

    if(totalX==0 && totalY==0 && totalZ == 0){
        cout<<"YES\n";
        }
    else
        cout<<"NO\n";
return 0;
}
