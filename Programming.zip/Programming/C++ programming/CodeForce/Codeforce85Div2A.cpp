#include<bits/stdc++.h>
int a,i;
char d[10006],m[100006];
int main(){
	scanf("%s %s",d,m);

	a=strlen(d);

	for(i=0 ; i<a ; i++){
		if(d[i] < 'a')
			d[i]+=32;
		if(m[i] < 'a')
			m[i]+=32;

		}

	if(strcmp(d,m) >= 1)
		puts("1");
	else if(strcmp(d,m) <= -1)
		puts("-1");
	else
		puts("0");

	return 0;
}
