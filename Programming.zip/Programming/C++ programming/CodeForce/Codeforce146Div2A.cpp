#include<bits/stdc++.h>
using namespace std;

int main()
{
    string s;
    int length;
    cin>>s;

    unordered_map<char, int> m;
    for (int i = 0; i < s.length(); i++) {
        m[s[i]];
    }

    length = m.size();

    if(length%2==0)
        cout<<"CHAT WITH HER!"<<endl;
    else
        cout<<"IGNORE HIM!"<<endl;

    return 0;
}
