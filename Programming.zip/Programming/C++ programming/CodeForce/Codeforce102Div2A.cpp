#include<bits/stdc++.h>
using namespace std;
int main(){
    int a = INT_MAX;
    int b = INT_MIN;
    int arr[1];
    cin>>arr[0];
    if(arr[0]>a)
        a=arr[0];
        cout<<arr[0];
return 0;
}
