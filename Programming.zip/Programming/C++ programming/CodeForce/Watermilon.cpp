#include<bits/stdc++.h>
using namespace std;
int main(){
    int W;
    int each_part,mod;
    cin>>W;
     if(W>2 && W%2==0)
        cout<<"YES";
     else
        cout<<"NO";
   return 0;
}

