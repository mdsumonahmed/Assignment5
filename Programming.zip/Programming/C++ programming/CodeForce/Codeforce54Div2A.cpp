#include<bits/stdc++.h>
using namespace std;

int main(){
    string s,hello="";
    cin>>s;

    for(int i=0; i<s.size(); i++){
        if(hello=="" && s[i]=='h') hello+=s[i];
        else if(hello=="h" && s[i]=='e') hello +=s[i];
        else if(hello=="he" && s[i]=='l') hello +=s[i];
        else if(hello=="hel" && s[i]=='l') hello +=s[i];
        else if(hello=="hell" && s[i]=='o') hello +=s[i];
    }

    if(hello == "hello")
        cout<<"YES";
    else
        cout<<"NO";

}
