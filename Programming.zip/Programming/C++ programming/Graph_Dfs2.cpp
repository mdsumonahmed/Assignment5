#include<bits/stdc++.h>
using namespace std;

vector<int>graph[5];
bool visit[5];

void dfs(int source)
{
    visit[source] = 1;
    for (int i=0; i<graph[source].size(); i++){
        int next = graph[source][i];
        if(visit[next]==0)
            dfs(next);
    }
}

int main()
{
    int nodes,edges;
    cin>>nodes>>edges;
    for(int i=0; i<edges; i++){
        int u,v;
        cin>>u>>v;
        graph[u].push_back(v);
        graph[v].push_back(u);
    }
    dfs(0);
    for(int i=0; i<5; i++){
        if(visit[i]==1)
            cout<<"Node "<<i<<" is visited\n";
        else
            cout<<"Node "<<i<<" is unvisited\n";
    }
return 0;
}
