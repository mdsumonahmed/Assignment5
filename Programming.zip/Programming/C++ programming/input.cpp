#include<iostream>
using namespace std;
main(){
    int a,b,c;
    cin>>a>>b;
    cout<<a<<endl;
    cout<<b<<endl;
    c=a+b;
    cout<<a+b<<endl;
    return 0;
}
