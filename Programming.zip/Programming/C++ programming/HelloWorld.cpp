#include<iostream>
using namespace std;
int main(){

    int i,temp;
    int n = 6;
    int arr[7] = {3,4,5,2,9,1,1};
    int r=n/2;
    int j = 1;
    for(i=0; i<r-1; i++){
        temp = arr[j];
        arr[j] = arr[n-1];
        arr[n-1] = temp;
        j = j+2;
        n = n-1;

    }
    for(int j = 0; j<7; j++){
         cout<<arr[j]<<" ";
    }

return 0;
}
