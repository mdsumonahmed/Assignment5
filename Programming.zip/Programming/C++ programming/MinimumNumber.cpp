#include<bits/stdc++.h>
using namespace std;
int find_min(int a,int b,int c){
    if(a<b && a<c)
        return a;
    else if(b<a && b<c)
            return b;
    else
        return c;
}
int main(){
    int a,b,c;
    cin>>a>>b>>c;
    cout<<find_min(a,b,c);

    return 0;
}
