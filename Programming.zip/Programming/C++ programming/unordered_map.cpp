#include<bits/stdc++.h>
using namespace std;

int main()
{   /*
    unordered_map<int, string>umap;
    umap[1] = "sumon";
    umap[2] = "ahmed";
    cout<<umap[2]<<endl;
    */
    string s;
    cin>>s;
    unordered_map<char, int> m;
    for (int i = 0; i < s.length(); i++) {
        m[s[i]];
    }

    cout<<m.size()<<endl;
    return 0;
}
