#include<iostream>
using namespace std;
class babartaka{
    public:
    int taka;
    int land;
    int gettaka();
    void setland(int la);
    private :
    int babartaka;

};
int babartaka::gettaka(){
return taka;
}
void babartaka::setland(int la){
land = la;
}
class amartaka : private babartaka
{
public:
    int building;

};
int main(){
babartaka amar;
amartaka nijer;
amar.taka = 20000;
amar.land = 500;
nijer.building = 3;

cout<<amar.taka<<endl;
cout<<amar.land<<endl;
cout<<nijer.building<<endl;

return 0;



}
