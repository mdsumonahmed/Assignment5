#include<iostream>
using namespace std;
main(){
    int a;
    int b;
    cin>>a;
    //b = a%2;
    if(a%2==0){
        cout<<"even"<<endl;
    }
    else if(a%2!= 0){
         cout<<"odd"<<endl;
    }


    return 0;
}
