#include<bits/stdc++.h>
using namespace std;

int main(){
    int var,y;
    cin>>y;
    /*if(y>10)
        var=40;
    else
        var=30;*/

    var = (y>10)? 40:30;
    cout<<var;
return 0;
}
